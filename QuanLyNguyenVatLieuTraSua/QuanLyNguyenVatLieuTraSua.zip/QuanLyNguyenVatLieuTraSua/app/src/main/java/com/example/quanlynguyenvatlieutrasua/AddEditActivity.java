package com.example.quanlynguyenvatlieutrasua;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.quanlynguyenvatlieutrasua.Model.Product;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;

public class AddEditActivity extends AppCompatActivity {

    private Button btn_select_date;
    private EditText nameProduct;
    private EditText qtyProduct;
    private EditText priceProduct;
    private EditText dateAddedProduct;
    private EditText idProduct;
    private Button btnSave;
    private Button btnCancel;

    private Product product = null;
    private int selectYear;
    private int selectMonth;
    private int selectDayOfMonth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);

        btn_select_date = (Button) findViewById(R.id.btn_select_date);
        nameProduct = (EditText) findViewById(R.id.nameProduct);
        qtyProduct = (EditText) findViewById(R.id.qtyProduct);
        priceProduct = (EditText) findViewById(R.id.priceProduct);
        dateAddedProduct = (EditText) findViewById(R.id.dateAddedProduct);
        idProduct = (EditText) findViewById(R.id.idProduct);
        btnSave = (Button) findViewById(R.id.btnAdd);
        btnCancel = (Button) findViewById(R.id.btnCancel);

        btn_select_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectDate(view);
            }
        });

        final Calendar c = Calendar.getInstance();
        selectYear = c.get(Calendar.YEAR);
        selectMonth = c.get(Calendar.MONTH);
        selectDayOfMonth = c.get(Calendar.DAY_OF_MONTH);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save(view);
            }

        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddEditActivity.this.onBackPressed();
            }
        });

    }

    private void save(View v){
        product = new Product();
        String newId = idProduct.getText().toString();
        String newPrice = priceProduct.getText().toString();
        String newName = nameProduct.getText().toString();
        String newQty = qtyProduct.getText().toString();
        String newDate = dateAddedProduct.getText().toString();
        if(!newId.matches("") && !newPrice.matches("")
                && !newName.matches("")
                && !newQty.matches("") && !newDate.matches("")){
            product.setIdProduct(newId);
            product.setPriceProduct(Integer.parseInt(newPrice));
            product.setNameProduct(newName);
            product.setQuantityProduct(newQty);
            product.setDateAdded(newDate);
            Toast.makeText(this.getApplicationContext(),"Add Success",Toast.LENGTH_SHORT).show();
            this.onBackPressed();
        }else {
            Toast.makeText(this.getApplicationContext(), "Vui Lòng Nhập Đầy Đủ Thông Tin!", Toast.LENGTH_LONG).show();
        }
    }

    private void selectDate(View v){
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                dateAddedProduct.setText(dayOfMonth + "-" + (month - 1) + "-" + year);
                selectYear = year;
                selectMonth = month;
                selectDayOfMonth = dayOfMonth;
            }
        };
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, android.R.style.Theme_Holo_Light_NoActionBar,dateSetListener,selectYear,selectMonth,selectDayOfMonth);
        datePickerDialog.show();
    }

    @Override
    public void finish() {
        Intent intent = new Intent();
        intent.putExtra("needRefresh",true);
        intent.putExtra("newProduct",product);
        if(product != null){
            setResult(RESULT_OK,intent);
        }else setResult(RESULT_CANCELED,intent);
        super.finish();
    }
}