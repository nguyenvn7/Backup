package com.example.quanlynguyenvatlieutrasua;

import android.content.Intent;
import android.os.Bundle;

import com.example.quanlynguyenvatlieutrasua.Model.Product;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.quanlynguyenvatlieutrasua.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private ListView listView;
    private FloatingActionButton add_button;
    private List<Product> productList = new ArrayList<>();
    private ArrayAdapter<Product> listViewAdapter;
    private ActivityResultLauncher<Intent> mGetContent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);



        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddEditActivity.class);
                mGetContent.launch(intent);
            }
        });

        this.productList = Product.createProduct();
        this.listView = (ListView)findViewById(R.id.dsach);
        this.listViewAdapter = new ArrayAdapter<Product>(this, android.R.layout.simple_list_item_1,this.productList);
        this.listView.setAdapter(this.listViewAdapter);
        registerForContextMenu(this.listView);

        mGetContent = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == RESULT_OK){
                            Intent data = result.getData();
                            Product newProduct = (Product) data.getSerializableExtra("newProduct");
                            MainActivity.this.productList.add(newProduct);
                            MainActivity.this.listViewAdapter.notifyDataSetChanged();
                        }
                    }
                });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_delete) {
            confirmDialog();
        }

        return super.onOptionsItemSelected(item);
    }

    public void confirmDialog(){

    }

}